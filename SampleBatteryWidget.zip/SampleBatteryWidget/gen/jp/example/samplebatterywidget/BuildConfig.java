/** Automatically generated file. DO NOT MODIFY */
package jp.example.samplebatterywidget;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}